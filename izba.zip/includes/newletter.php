<div class="footer-newsletter">
      <div class="container">
            <div class="row justify-content-center">
                    <div class="col-lg-8">
                      <div class="section-title">
                        <h2>Aktualności</h2>
                        <h3>Nasze <span>aktualności</span></h3>
                        <p>Pragniesz być na bieżąco z naszymi aktualnościami, 
                          zapisz się, byśmy mogli Was informować na bieżąco</p>
                      </div> 
                      <div>
                        <form action="" method="post">
                        <input type="email" name="email"><input type="submit" value="Zapisz się">
                      </form>
                      </div>           
                    
                    </div>
            </div>
      </div>
</div>
 