
  <section class="banner" id="top">
    <div class="container-fluid " >
        <div class="row">
            <div class="col-lg-8">
                
                <div class="left-banner-content">
                    <div class="text-content" data-aos="zoom-in" data-aos-delay="100">
                      
                         <h3>Łączymy się razem</h3>
                        <div class="line-dec"></div>
                         <h1>ZWIĄZEK TELEWIZJI KABLOWYCH</h1> 
                         <h2>W POLSCE</h2>
                         <h1>IZBA GOSPODARCZA</h1>
                         
                          <a class="coolBeans " href="#">czytaj więcej</a>
                        
                       
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="right-banner-content" >
                  <img src="assets/img/ztkig/logo_transparent.png" class="img-fluid" data-aos="zoom-in-down" data-aos-delay="500" alt="">
                    <div class="right-banner-text" data-aos="zoom-in" data-aos-delay="100">
                      <h3>Wspólnie od 1998</h3>
                      <span> <em>jednoczymy w grupę </em> </span><br>
                      <span> <em>łączącą polskie telewizje kablowe </em> </span>

                    <div class="line-dec"></div>
                    
                    <h3>Dołączcie też Wy</h3>
                       
                </div>
            </div>
        </div>
    </div>
</section>

 