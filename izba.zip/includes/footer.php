<br>
<footer id="footer">

   


    
    <div class="footer-top" style="background-color: #b6cae9;" >
      <div class="container" >
        <div class="row">

          <div class="col-sm-6 footer-contact" style="text-align: center;">
            <h3>Związek Telewizji <br>
            Kablowych <br>
            w Polsce <br>
            Izba Gospodarcza</h3>
            
          </div>

          <div class="col-sm-3 footer-links"  >
            <p>
              ul. Traugutta 25 <br>
              90-113 Łódź<br>
              Polska <br><br>
               <br>
            </p>
          </div>

          <div class="col-sm-3 footer-links" >
            <strong>Telefon:</strong>+48 606 368 161<br>
              <strong>Email:  </strong><a href="mailto:ztk@ztkig.pl">ztk@ztkig.pl</a>
          </div>

         

        </div>
      </div>
    </div>

    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span>ztkig</span></strong>. Wszystkie prawa zastrzeżone
      </div>
      <div class="credits">
          Created by <a href="https://www.linkedin.com/in/sebastian-ubycha-874a69b5/" target="_blank">SUB</a>
      </div>
    </div>
  </footer><!-- End Footer -->