<!-- ======= Counts Section ======= -->
<br>
<section id="counts" class="counts">
                <div class="container" data-aos="fade-up">
                    
                    <div class="row">
                    <div class="section-title"> 
                        <h2>Rynek</h2>           
                        <h3>Rynek <span>Telewizji kablowych</span> w Polsce</h3>
                        <p>Rynek telewizyjny od 1989 roku znacznie się rozwinął, a my wspólnie mamy na to znaczący wpływ</p>
                    </div>
                    </div>  

                    <div class="row">



                    <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
                        <div class="count-box">
                        <i class="bi bi-people"></i>
                        <span data-purecounter-start="0" data-purecounter-end="5000000" data-purecounter-duration="1.7" class="purecounter"></span>
                        <p>Abonentów <br>sieci kablowych</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="count-box">
                        <i class="bi bi-tv"></i>
                        <span data-purecounter-start="0" data-purecounter-end="500" data-purecounter-duration="1.5" class="purecounter"></span>
                        <p>Operatorów sieci <br> telewizji kablowej</p>
                        </div>
                    </div>

                    
                    <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
                        <div class="count-box">
                        <i class="bi bi-geo-alt"></i>
                        <span data-purecounter-start="0" data-purecounter-end="300" data-purecounter-duration="1.5" class="purecounter"></span>
                        <p> Miast <br>w Polsce</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
                        <div class="count-box">
                        <i class="bi bi-headset"></i>
                        <span data-purecounter-start="0" data-purecounter-end="120" data-purecounter-duration="100" class="purecounter"></span>
                        <p>Niezależnych <br> redakcji</p>
                        </div>
                    </div>

                    </div>

                </div>
                </section>