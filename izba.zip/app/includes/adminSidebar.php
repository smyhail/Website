<div class="left-sidebar">
    <ul>       
        <li><a href="<?php echo BASE_URL . '/admin/posts/index.php'; ?>">Zarządzaj postami</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/users/index.php'; ?>">Zarządzaj użytkownikami</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/topics/index.php'; ?>">Zarządzaj kategoriami</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/news/index.php'; ?>">Zarządzaj aktualnościami</a></li>
        
    </ul>
</div>