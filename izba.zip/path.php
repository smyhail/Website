<?php

define("ROOT_PATH", realpath(dirname(__FILE__)));
//define("BASE_URL", "http://localhost/_izba/blog_3m");
define("BASE_URL", "/izba_000");
